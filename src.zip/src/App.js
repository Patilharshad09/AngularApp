import React from 'react';
// import logo from './logo.svg';
import './App.css';
import SideBar from './Components/shared/sidebar';
import Header from './Components/shared/Header';
import Notifications from './Components/shared/Notifications';
import ActivityList from './Components/General/activityList';
import CheckList from './Components/General/checkList';
import NewList from './Components/General/newsList';

export const activities = {
  data: [{
    time: '5.30 PM',
    dueStatus: '6 hours ago',
    title: 'Madhuri Bhatia - Client Statement',
    activityName: 'Prepare client statement for Jun-2019'
  }, {
    time: '4.30 PM',
    dueStatus: '6 hours ago',
    title: 'Vidya - Client Statement',
    activityName: 'Prepare client statement for Jun-2019'
  }],
  noData: {
    title: ' No Recent Activities'
  }
};
export const checkListItems = {
  data: [{

    title: 'Madhuri Bhatia - Client Statement',
  }, {
    title: 'Vidya - Client Statement',
  }, {
    title: 'INE20283J31 - Belstar Pvt Ltd 12.4% 20-May-2020 is bought',
  }],
  noData: {
    title: ' No Recent Activities'
  }
};

export const NewsFeedsList = {
  data: [{
    "author": "Moneycontrol.com",
    "title": "ILFS to run Gurgaon Metro till September 17, HUDA to bear cost: HC",
    "headLine": "The Gurgaon Metro is the country#39;s first fully privately-developed project which was built by the Infrastructure Leasing Financial Services (ILFS).",
    "url": "https://www.moneycontrol.com/news/business/real-estate/ilfs-to-run-gurgaon-metro-till-september-17-huda-to-bear-cost-hc-4419611.html",
    "urlToImage": "https://static-news.moneycontrol.com/static-mcnews/2019/02/gurgaon-rapid-metro-770x433.jpg",
    "date": "10",
    "month": "Sep",
    "content": "The Gurgaon Metro will be operated and maintained by IL&FS till September 17 midnight as a licensee while its operational cost will be borne by the Haryana Urban Development Authority, the Punjab and Haryana High Court ruled on September 9.\r\nThe court als… [+3180 chars]"
  },
  {
    "author": "Moneycontrol.com",
    "title": "Gurgaon Metro: Punjab and Haryana HC orders CAG to audit debt due",
    "headLine": "The Gurgaon Metro is the country#39;s first fully privately developed project which was built by ILFS, which is now facing bankruptcy proceedings in the NCLAT, putting the rail service at risk of closure.",
    "url": "https://www.moneycontrol.com/news/business/real-estate/ilfs-to-run-gurgaon-metro-till-september-17-huda-to-bear-cost-hc-4419611.html",
    "urlToImage": "https://static-news.moneycontrol.com/static-mcnews/2019/02/gurgaon-rapid-metro-770x433.jpg",
    "date": "27",
    "month": "Sep",
    "content": "The Ministry of Corporate affairs on September 27 moved the National Company Law Tribunal to file an application seeking a change in the auditors of Infrastructure Leasing and Financial Services Ltd.\r\nThe move comes in the wake of Supreme Court allowing gover… [+1131 chars]"
  }],
  noData: {
    title: 'No Recent Activities'
  }
}
function App(props) {
  return (
    <div>
      <Notifications />
      <SideBar />
      <div className="page">
        <Header />
        <section className="mt-30px mb-30px">
          <div className="container-fluid">
            <div className="row">
              <div className="col-lg-3 col-md-12">
                <div id="new-updates" className="card updates recent-updated">
                  <div id="updates-header" className="card-header d-flex justify-content-between align-items-center">
                    <h2 className="h5 display"><a data-toggle="collapse" data-parent="#new-updates" href="#updates-box" aria-expanded="true" aria-controls="updates-box">News Updates</a></h2><a data-toggle="collapse" data-parent="#new-updates" href="#updates-box" aria-expanded="true" aria-controls="updates-box"><i className="fa fa-angle-down"></i></a>
                  </div>
                  <div id="updates-box" role="tabpanel" className="collapse show">
                    <NewList {...NewsFeedsList} />
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6">
                <div id="daily-feeds" className="card updates daily-feeds">
                  <div id="feeds-header" className="card-header d-flex justify-content-between align-items-center">
                    <h2 className="h5 display"><a data-toggle="collapse" data-parent="#daily-feeds" href="#feeds-box" aria-expanded="true" aria-controls="feeds-box">Your daily Feeds </a></h2>
                    <div className="right-column">
                      <div className="badge badge-primary">10 messages</div><a data-toggle="collapse" data-parent="#daily-feeds" href="#feeds-box" aria-expanded="true" aria-controls="feeds-box"><i className="fa fa-angle-down"></i></a>
                    </div>
                  </div>
                  <div id="feeds-box" role="tabpanel" className="collapse show">
                    <div className="feed-box">
                      <ul className="feed-elements list-unstyled">
                        <li className="clearfix">
                          <div className="feed d-flex justify-content-between">
                            <div className="feed-body d-flex justify-content-between"><a href="/" className="feed-profile"><img src="img/avatar-5.jpg" alt="person" className="img-fluid rounded-circle" /></a>
                              <div className="content"><strong>Aria Smith</strong><small>Posted a new blog </small>
                                <div className="full-date"><small>Today 5:60 pm - 12.06.2014</small></div>
                              </div>
                            </div>
                            <div className="date"><small>5min ago</small></div>
                          </div>
                        </li>
                        <li className="clearfix">
                          <div className="feed d-flex justify-content-between">
                            <div className="feed-body d-flex justify-content-between"><a href="/" className="feed-profile"><img src="img/avatar-2.jpg" alt="person" className="img-fluid rounded-circle" /></a>
                              <div className="content"><strong>Frank Williams</strong><small>Posted a new blog </small>
                                <div className="full-date"><small>Today 5:60 pm - 12.06.2014</small></div>
                                <div className="CTAs"><a href="/" className="btn btn-xs btn-dark"><i className="fa fa-thumbs-up">
                                </i>Like</a><a href="/" className="btn btn-xs btn-dark"><i className="fa fa-heart"> </i>Love</a>
                                </div>
                              </div>
                            </div>
                            <div className="date"><small>5min ago</small></div>
                          </div>
                        </li>
                        <li className="clearfix">
                          <div className="feed d-flex justify-content-between">
                            <div className="feed-body d-flex justify-content-between"><a href="/" className="feed-profile"><img src="img/avatar-3.jpg" alt="person" className="img-fluid rounded-circle" /></a>
                              <div className="content"><strong>Ashley Wood</strong><small>Posted a new blog </small>
                                <div className="full-date"><small>Today 5:60 pm - 12.06.2014</small></div>
                              </div>
                            </div>
                            <div className="date"><small>5min ago</small></div>
                          </div>
                        </li>
                        <li className="clearfix">
                          <div className="feed d-flex justify-content-between">
                            <div className="feed-body d-flex justify-content-between"><a href="/" className="feed-profile"><img src="img/avatar-1.jpg" alt="person" className="img-fluid rounded-circle" /></a>
                              <div className="content"><strong>Jason Doe</strong><small>Posted a new blog </small>
                                <div className="full-date"><small>Today 5:60 pm - 12.06.2014</small></div>
                              </div>
                            </div>
                            <div className="date"><small>5min ago</small></div>
                          </div>
                          <div className="message-card"> <small>Lorem Ipsum is simply dummy text of the printing and typesetting
                              industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. Over
                          the years, sometimes by accident, sometimes on purpose (injected humour and the like).</small>
                          </div>
                          <div className="CTAs pull-right"><a href="/" className="btn btn-xs btn-dark"><i className="fa fa-thumbs-up">
                          </i>Like</a></div>
                        </li>
                        <li className="clearfix">
                          <div className="feed d-flex justify-content-between">
                            <div className="feed-body d-flex justify-content-between"><a href="/" className="feed-profile"><img src="img/avatar-6.jpg" alt="person" className="img-fluid rounded-circle" /></a>
                              <div className="content"><strong>Sam Martinez</strong><small>Posted a new blog </small>
                                <div className="full-date"><small>Today 5:60 pm - 12.06.2014</small></div>
                              </div>
                            </div>
                            <div className="date"><small>5min ago</small></div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6">
                <div id="recent-activities-wrapper" className="card updates activities">
                  <div id="activites-header" className="card-header d-flex justify-content-between align-items-center">
                    <h2 className="h5 display"><a data-toggle="collapse" data-parent="#recent-activities-wrapper" href="#activities-box" aria-expanded="true" aria-controls="activities-box">Recent Activities</a>
                    </h2><a data-toggle="collapse" data-parent="#recent-activities-wrapper" href="#activities-box" aria-expanded="true" aria-controls="activities-box"><i className="fa fa-angle-down"></i></a>
                  </div>
                  <div id="activities-box" role="tabpanel" className="collapse show">
                    <ActivityList {...activities} />
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6">
                <div className="card to-do">
                  <h2 className="display h4">To do List</h2>
                  <p>Check List</p>
                  <div>
                    <CheckList {...checkListItems} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default App;