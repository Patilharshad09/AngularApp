import React from 'react';
import { Container, Header, Content, List, ListItem, Thumbnail, Text, Left, Body, Right, Button, Icon } from 'native-base';

export default class GroupExposure extends React.Component {
    componentDidMount() {
    }

    render() {
        return (
            // <List>
            <ListItem Thumbnail onPress={() => this.props.clickhandler(this.props.exposure)}>
                <Body >
                    <Text>{this.props.exposure['Group Name']} <Text note>({this.props.exposure['AK Company']})</Text></Text>
                    <Text note numberOfLines={1}>
                        Limit : {this.props.exposure['Group Exposure Limit']}&nbsp;
                            POS : {this.props.exposure['Principal Outstanding']}&nbsp;
                            Avail :{this.props.exposure['Group Limit Available']}
                    </Text>
                </Body>
                <Right>
                    <Button transparent onPress={() => this.props.clickhandler(this.props.exposure)}>
                        <Icon name="arrow-down" />
                    </Button>
                </Right>
            </ListItem>
            //</List>
        );
    }


    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}