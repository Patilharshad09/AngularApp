import React from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import GroupExposure from './GroupExposure';
import groupExposure from '../../../src/groupExposure.json';
import { StyleSheet, FlatList, Text, Dimensions } from "react-native";
import { Container, Header, Content, List, InputGroup, Input, Icon, Col, View, Button } from 'native-base';

import axios from 'axios';
const numOfCols = 4;
const alphabets = [{ key: 'A' },
{ key: 'B' },
{ key: 'C' },
{ key: 'D' },
{ key: 'E' },
{ key: 'F' },
{ key: 'G' },
{ key: 'H' },
{ key: 'I' },
{ key: 'J' },
{ key: 'K' },
{ key: 'L' },
{ key: 'M' },
{ key: 'N' },
{ key: 'O' },
{ key: 'P' },
{ key: 'Q' },
{ key: 'R' },
{ key: 'S' },
{ key: 'T' },
{ key: 'U' },
{ key: 'V' },
{ key: 'W' },
{ key: 'X' },
{ key: 'Y' },
{ key: 'Z' },
];
const formatData = (alphabets, numOfCols) => {
    let noofRows = Math.floor(alphabets.length / numOfCols);
    let lastRowEle = alphabets.length - (noofRows * numOfCols);
    while (numOfCols !== lastRowEle && lastRowEle !== 0) {
        alphabets.push({ key: `blank-${lastRowEle}`, empty: true });
        lastRowEle++;
    }
    return alphabets;
}
export default class Exposure extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };
    constructor() {
        super();
        this.state = {
            groupExposure: [],
            rawData: [],
            groupName: '',
            loading: false
        }
    }
    onSearch = (event) => {
        this.setState((state, props) => ({
            groupName: event,
            loading: true
        }));
        if (event.length > 0) {
            var d = this.state.rawData.filter((item) => {
                if (item['Group Name'].toLowerCase().indexOf(event.trim().toLowerCase()) > -1)
                    return item;
            });
            this.setState({
                groupExposure: d,
                loading: false
            })
        }
        else {
            this.setState((prevState) => ({
                groupExposure: prevState.rawData,
                loading: false
            }));
        }
    }
    componentDidMount() {
        this.setState({
            groupExposure: groupExposure,
            rawData: groupExposure,
            groupName: '',
            loading: false
        });
    }

    renderBlock = ({ item, index }) => {
        if (item.empty === true) {
            return <View style={[styles.item, styles.invisible]}></View>
        }
        return (
            <View style={styles.item}>
                <Text style={styles.itemText} >{item.key}</Text>
            </View>);
    }
    render() {

        return (
            <Container>
                <Header transparent>
                    <InputGroup style={{ flex: 1, flexDirection: 'row' }}>
                        <Icon name="search" style={{ color: '#384850' }} />
                        <Input style={{ color: '#00c497' }} value={this.state.groupName}
                            onChangeText={this.onSearch} />
                    </InputGroup>
                </Header>
                <Content>
                    <FlatList data={formatData(alphabets, numOfCols)}
                        style={styles.container}
                        renderItem={this.renderBlock}
                        numColumns={numOfCols}
                    />

                    {/* {<List dataArray={this.state.groupExposure} renderRow={(item, i) =>
                        <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />
                    } />} */}
                </Content>
            </Container>
        );
    }
    _showMoreApp = (d) => {
        this.props.navigation.navigate('IssuerExposure', {
            group: d
        });
    };
    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    item: {
        backgroundColor: '#005493',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        margin: 1,
        height: Dimensions.get('window').width / numOfCols
    },
    itemText: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold'
    },
    invisible: {
        backgroundColor: "transparent"
    }
})