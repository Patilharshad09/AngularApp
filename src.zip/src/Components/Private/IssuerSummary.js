import React, { Component } from "react";
import { Container, Header, Content, List, Title, ListItem, Text, Left, Body, Right, Button, Icon } from 'native-base';
import SinglepartyDetails from '../../../src/SinglePartyDetails.json';

export default class IssuerSummary extends Component {
    constructor() {
        super();
        this.state = {
            SinglepartyDetails: SinglepartyDetails,
            rawData: SinglepartyDetails,
            filterGroup: {}
        }
    }
    componentDidMount() {
        this.setState({
            SinglepartyDetails: SinglepartyDetails,
            rawData: SinglepartyDetails
        })

        this.props.navigation.addListener('willFocus', this.loadIssuerExposure)
    }

    componentWillUnmount() {

    }

    loadIssuerExposure = () => {
        var filterGroup = null;
        filterGroup = this.props.navigation.getParam('company', []);
        this.setState({ filterGroup: filterGroup });
        // var d = [];
        // if (filterGroup) {
        //     d = this.state.rawData.filter(item => {
        //         return (filterGroup['Company Name'] === item['Company Name'] && filterGroup['AK Company'] === item['AK Company']);
        //     });
        //     this.setState({
        //         SinglepartyDetails: d,
        //         rawData: SinglepartyDetails
        //     });
        // }
        // else {
        //     this.state = {
        //         SinglepartyDetails: rawData,
        //         rawData: rawData
        //     }
        // }
    }

    render() {
        return (

            <Container>
                <Content>
                    <Header>
                        <Left>
                            <Button transparent onPress={() => this.props.navigation.goBack()}>
                                <Icon name='arrow-back' />
                            </Button>
                        </Left>
                        <Body>
                            <Title>{this.state.filterGroup['Company Name']} <Text note>({this.state.filterGroup['AK Company']})</Text></Title>
                        </Body>

                    </Header>
                    {this.state.SinglepartyDetails ? this.state.SinglepartyDetails.map((item, i) => {
                        return (
                            <List key={i}>
                                <ListItem Thumbnail>

                                    <Body>
                                        <Text>{item['ISIN']}</Text>
                                        <Text note numberOfLines={1}>POS : {item['Principal Outstanding']}</Text>
                                        <Text note numberOfLines={1}>Interest Overdue : {item['Interest OverDue']}</Text>
                                        <Text note numberOfLines={1}>Interest Due Today : {item['Interest Due Today']}</Text>
                                        <Text note numberOfLines={1}>Unutilized : {item['Unutilized Amount']}</Text>
                                        <Text note numberOfLines={1}>Commited : {item['Tranche Amount']}</Text>
                                    </Body>
                                    <Right>
                                        {/* <Button onPress={() => this.props.clickhandler(item)}>
                                            <Icon name="arrow-down" />
                                        </Button> */}
                                    </Right>
                                </ListItem>
                            </List>
                        )
                    }) : <Text>Do Data Found</Text>}
                </Content>
            </Container>

        );
    }
}