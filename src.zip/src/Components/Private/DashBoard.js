import React from 'react';
import { View, Text, Button, Platform, SafeAreaView,AsyncStorage } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';



export default class DashBoard extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };

    render() {
        return (
            <SafeAreaView>
                <View>
                    <Text>DashBoard</Text>
                    <Button title="Show me more of the app" onPress={this._showMoreApp} />
                    <Button title="Actually, sign me out :)" onPress={this._signOutAsync} />
                </View>
            </SafeAreaView>
        );
    }

    _showMoreApp = () => {
        this.props.navigation.navigate('Other');
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}