import React from "react";
import { View } from "react-native";
import { Button } from "react-native-elements";
import { onSignIn } from "../Auth/AuthLoading";

export default class SignIn extends React.Component {
  render() {
    return (
      <View style={{ paddingVertical: 20 }}>

        <Button
          buttonStyle={{ marginTop: 20 }}
          backgroundColor="#03A9F4"
          title="SIGN IN"
          onPress={() => {
            onSignIn().then(() => this.props.navigation.navigate("App"));
          }}
        />

      </View>
    )
  }
};
