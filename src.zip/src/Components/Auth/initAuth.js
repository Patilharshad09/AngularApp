import React from 'react';
import { View, ActivityIndicator, StatusBar, AsyncStorage, SafeAreaView } from 'react-native';
const USER_KEY = "auth-demo-key";
export default class InitAuth extends React.Component {
    constructor() {
        super();
        this._bootstrapAsync();
    }

    // Fetch the token from storage then navigate to our appropriate place
    _bootstrapAsync = async () => {
        const userToken = await AsyncStorage.getItem('USER_KEY');

        // This will switch to the App screen or Auth screen and this loading
        // screen will be unmounted and thrown away.
        this.props.navigation.navigate(userToken ? 'App' : 'Auth');
    };

    // Render any loading content that you like here
    render() {
        return (
            <SafeAreaView>
                <View>
                    <ActivityIndicator />
                    <StatusBar barStyle="default" />
                </View>
            </SafeAreaView>
        );
    }
}