import React from 'react';

function CheckList(props) {
    const ele = props.data ? props.data.map((item, i) => {
        return (
            <li className="d-flex align-items-center" key={`checkList${i.toString()}`} >
                <input type="checkbox" className="form-control-custom" />
                <label>{item.title}</label>
            </li >
        );
    }) : <li className="d-flex align-items-center" key='checkList' >
            <label>{props.noData.title}</label>
        </li >

    return (
        <ul className="check-lists list-unstyled">
            {ele}
        </ul>
    );
}
export default CheckList;