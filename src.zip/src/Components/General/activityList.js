import React from 'react';

function ActivityList(props) {
    const ele = props.data ? props.data.map((item, i) => {
        return <li key={i}>
            <div className="row">
                <div className="col-4 date-holder text-right">
                    <div className="icon"><i className="icon-clock"></i></div>
                    <div className="date"> <span>{item.time}</span><span className="text-info">{item.dueStatus}</span></div>
                </div>
                <div className="col-8 content"><strong>{item.title}</strong>
                    <p>{item.activityName}</p>
                </div>
            </div>
        </li>
    }) : <li>
            <div className="row">
                <div className="col content"><strong>{props.noData.title}</strong>
                </div>
            </div>
        </li>
    return (
        <ul className="activities list-unstyled">
            {ele}
        </ul>
    );
}
export default ActivityList;