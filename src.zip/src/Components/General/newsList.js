import React from 'react';


function NewList(props) {
    const ele = props.data ? props.data.map((item, i) => {
        return (
            <li className="d-flex justify-content-between" key={`news${i}`}>
                <div className="left-col d-flex">
                    <div className="icon"><i className="icon-rss-feed"></i></div>
                    <div className="title"><strong>{item.title}</strong>
                        <p>{item.headLine}</p>
                    </div>
                </div>
                <div className="right-col text-right">
                    <div className="update-date">{item.date}<span className="month">{item.month}</span></div>
                </div>
            </li>
        );
    }) : <li className="d-flex justify-content-between">
            <div className="left-col d-flex">
                <div className="icon"><i className="icon-rss-feed"></i></div>
                <div className="title"><strong>{props.noData.title}</strong>
                </div>
            </div>

        </li>;
    return (
        <ul className="feed-elements list-unstyled">
            {ele}
        </ul>
    );
}
export default NewList;