import React from 'react';

function FeedList(props) {
    const ele = props.data ? props.data.map((item, i) => {
        return (
            <li className="clearfix">
                <div className="feed d-flex justify-content-between">
                    <div className="feed-body d-flex justify-content-between">
                        <a href={item.feedUrl} className="feed-profile">
                            <img src={item.feedAvatarUrl} alt="person" className="img-fluid rounded-circle" />
                        </a>
                        <div className="content"><strong>{item.source}</strong><small>{item.title} </small>
                            {item.headLine}
                        </div>
                    </div>
                    <div className="full-date"><small>{item.timeStamp}</small></div>
                </div>
                <div className="message-card">
                    <small>{item.child.headLine}
                    </small>
                </div>
                <div className="CTAs pull-right">
                    <a href="/" className="btn btn-xs btn-dark" >
                        <i className="fa fa-thumbs-up">
                        </i>Like
                    </a>
                </div>
            </li>
        );
    }) : <li className="clearfix">
            <div className="feed d-flex justify-content-between">
                <div className="feed-body d-flex justify-content-between">
                    <div className="content"><strong>{props.noData.title}</strong>
                    </div>
                </div>
            </div>
        </li>;
    return (
        <ul className="feed-elements list-unstyled">
            {ele}
        </ul>
    );
}

export default FeedList;