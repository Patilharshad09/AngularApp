import React from 'react';

function Notifications(props) {
    return (
        <ul className="messenger messenger-fixed messenger-on-top messenger-on-right messenger-theme-flat">
            <li className="messenger-message-slot">
                <div className="messenger-message message alert success message-success alert-success messenger-will-hide-after">
                    <button type="button" className="messenger-close" data-dismiss="alert">×</button>
                    <div className="messenger-message-inner">Hey, how are you?
                    <br />Welcome to the Material Admin Premium template by Bootstrapious.
                </div>
                    <div className="messenger-spinner">
                        <span className="messenger-spinner-side messenger-spinner-side-left">
                            <span className="messenger-spinner-fill"></span>
                        </span>
                        <span className="messenger-spinner-side messenger-spinner-side-right">
                            <span className="messenger-spinner-fill"></span>
                        </span>
                    </div>
                </div>
            </li>
        </ul>
    );
}

export default Notifications;