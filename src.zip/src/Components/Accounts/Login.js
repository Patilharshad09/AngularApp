import React from 'react';

class Login extends React.Component {
    render() {
        return (
            <div className="page login-page">
                <div className="container">
                    <div className="form-outer text-center d-flex align-items-center">
                        <div className="form-inner">
                            <div className="logo text-uppercase"><span>Building</span><strong className="text-primary">Bonds</strong></div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
                            <form method="get" className="text-left form-validate">
                                <div className="form-group-material">
                                    <input id="login-username" type="text" name="loginUsername" required data-msg="Please enter your username" className="input-material" />
                                    <label for="login-username" className="label-material">Username</label>
                                </div>
                                <div className="form-group-material">
                                    <input id="login-password" type="password" name="loginPassword" required data-msg="Please enter your password" className="input-material" />
                                    <label for="login-password" className="label-material">Password</label>
                                </div>
                                <div className="form-group text-center"><a id="login" href="index.html" className="btn btn-primary">Login</a>

                                </div>
                            </form>
                            <a href="/ForgotPassword" className="forgot-pass">Forgot Password?</a>
                        </div>
                        {/* <div className="copyrights text-center">
                            <p>Design by <a href="/" className="external">Your company</a>
                            </p>
                        </div> */}
                    </div>
                </div>
            </div>
        )
    }
}

export default Login;