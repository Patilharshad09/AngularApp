import React from "react";
import { InitAuth } from './src/Components/Auth/initAuth';
import { createSwitchNavigator } from "react-navigation";
import { AuthRoutes } from "../Routes/AuthRoutes";
import { AppRoutes } from "../Routes/AppRoutes";

export default createAppContainer(createSwitchNavigator(
    {
        InitAuth: InitAuth,
        App: AppRoutes,
        Auth: AuthRoutes,
    }
));
