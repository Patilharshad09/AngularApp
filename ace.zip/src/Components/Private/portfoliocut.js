import React from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import { StyleSheet, Text, } from "react-native";
import { Container, Header, Content, Item, Input, Icon, Button, Tab, Tabs, ScrollableTab } from 'native-base';
import { Post } from '../../Services/dataProvider';


export default class portfolioCut extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };
    constructor() {
        super();
        this.state = {
            portfolioCut: [],
            rawData: [],
            loading: false
        }
        this.portfolioCut = [];
    }

    componentDidMount() {
        try {
            this.setState({ loading: false });
            Post('getPortfolioCuts', null).then((response) => {
                this.portfolioCut = JSON.parse(response[1].valueField);
                this.setState({
                    portfolioCut: this.portfolioCut,
                    rawData: this.portfolioCut,
                    loading: false
                });
            });
        } catch (err) {
            Alert.alert("Oops! [Exposure-componentDidMount]", err);
            return false;
        };
    }
    renderBlock = () => {
        return this.state.portfolioCut.map(function (key, i) {
            return (
                <Tab key={i} heading={"tab-pane"}>
                    <Text>Text</Text>
                </Tab>
            );
        });
    }
    render() {
        // var renderBlock = this.renderBlock();
        return (

            <Container>
                <Header searchBar rounded>
                    <Item>
                        <Icon name="ios-search" />
                        <Input placeholder="Search" />
                        <Icon name="ios-people" />
                    </Item>
                    <Button transparent>
                        <Text>Search</Text>
                    </Button>
                </Header>
                <Content>
                    <Tabs renderTabBar={() => <ScrollableTab />}>
                        <Tab heading="tab">
                            <Text>Text</Text>
                        </Tab>
                    </Tabs>
                </Content>
            </Container>
        );
    }
    _showMoreApp = (d) => {
        try {
            var singlepartyData = this.state.rawSinglePartyData.filter((item) => {
                if (item['Group Name'].toLowerCase().indexOf(d['Group Name'].trim().toLowerCase()) > -1 && item['AK Company'] === d['AK Company'])
                    return item;
            });
            this.props.navigation.navigate('IssuerExposure', {
                group: d,
                singleParty: singlepartyData
            });
        } catch (err) {
            Alert.alert("Oops! [Exposure-_showMoreApp]", err);
            return false;
        };
    };
    _signOutAsync = async () => {
        try {
            await AsyncStorage.clear();
            this.props.navigation.navigate('Auth');
        } catch (err) {
            Alert.alert("Oops! [Exposure-_signOutAsync]", err);
            return false;
        };
    };
}
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    item: {
        backgroundColor: '#005493',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        margin: 1,
        // height: Dimensions.get('window').width / numOfCols
    },
    itemText: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold'
    },
    invisible: {
        backgroundColor: "transparent"
    }
})