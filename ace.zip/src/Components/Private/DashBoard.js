import React from 'react';
import { View, Text, Button, Platform, SafeAreaView } from 'react-native';
// import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import CollapsiblePanel from '../Shared/collapsiblePanal';
import Notifications from './Notifications';
export default class DashBoard extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };

    render() {
        const components = {
            photo: Notifications,
            video: CollapsiblePanel
        };
        const Component = components['video'];
        return (<Component />);

    }

    _showMoreApp = () => {
        this.props.navigation.navigate('Other');
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}