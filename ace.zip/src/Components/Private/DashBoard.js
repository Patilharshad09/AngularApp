import React from 'react';
import { View, Text, Button, Platform, SafeAreaView } from 'react-native';
// import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-community/async-storage';
import CollapsiblePanel from '../Shared/collapsiblePanal';

export default class DashBoard extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };

    render() {
        return (
            <SafeAreaView>
                <View>
                    <Text>DashBoard</Text>
                    <CollapsiblePanel />
                    <CollapsiblePanel />
                    {/* <Button title="Show me more of the app" onPress={this._showMoreApp} />
                    <Button title="Actually, sign me out :)" onPress={this._signOutAsync} /> */}
                </View>
            </SafeAreaView>
        );
    }

    _showMoreApp = () => {
        this.props.navigation.navigate('Other');
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}