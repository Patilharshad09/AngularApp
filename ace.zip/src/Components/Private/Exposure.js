import React from 'react';
import { View, Text } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import GroupExposure from './GroupExposure';
import groupExposure from '../../../src/groupExposure.json';
// import { Container, Header, Content, Card, CardItem, Text, Body, Button } from "native-base";
import { Container, Content } from 'native-base';
import axios from 'axios';

export default class Exposure extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };
    constructor() {
        super();
        this.state = {
            groupExposure: []
        }
    }
    componentDidMount() {

        this.setState({
            groupExposure: groupExposure
        })
    }
    render() {

        return (
            <Container>
                <Content>
                    {this.state.groupExposure.map((item, i) => {
                        return (
                            <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />
                        )
                    })}
                </Content>
            </Container>
        );
    }

    _showMoreApp = (d) => {
        this.props.navigation.navigate('IssuerExposure', {
            group: d
        });
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}