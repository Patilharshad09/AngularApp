import React, { Component } from "react";
import { Container, Header, Content, List, Title, ListItem, Text, Left, Body, Right, Button, Icon } from 'native-base';
import { Post } from "../../Services/dataProvider";


export default class IssuerSummary extends Component {
    constructor() {
        super();
        this.state = {
            SinglepartyDetails: [],
            rawData: [],
            filter: {}
        }
    }
    componentDidMount() {
        this.setState({
            SinglepartyDetails: [],
            rawData: []
        })
        //this.props.navigation.addListener('willFocus', this.loadIssuerExposure)
        this.loadIssuerExposure();
    }

    componentWillUnmount() {

    }

    loadIssuerExposure = () => {
        var filter = null;
        filter = this.props.navigation.getParam('company', []);
        this.setState({ filter: filter });
        Post('getDetailedDataForSingleParty', { AKCompanyId: filter['AK CompanyId'], Borrower: filter['Company Name'] }).then((response) => {
            this.setState({
                SinglepartyDetails: response,
                rawData: response,
                filter: filter,
                loading: false
            });
        });
    }

    render() {
        return (

            <Container style={{ marginTop: 20 }}>
                <Content>
                    <Header>
                        <Left>
                            <Button transparent onPress={() => this.props.navigation.goBack()}>
                                <Icon name='arrow-back' />
                            </Button>
                        </Left>
                        <Body>
                            <Title>{this.state.filter['Company Name']} <Text note>({this.state.filter['AK Company']})</Text></Title>
                        </Body>

                    </Header>
                    {this.state.SinglepartyDetails ? this.state.SinglepartyDetails.map((item, i) => {
                        return (
                            <List key={i}>
                                <ListItem Thumbnail>

                                    <Body>
                                        <Text>{item['Product']} - {item['PAN / ISIN']}</Text>
                                        <Text note numberOfLines={1}>POS : {item['Principal Outstanding']}</Text>
                                        <Text note numberOfLines={1}>Interest Overdue : {item['Interest OverDue']}</Text>
                                        <Text note numberOfLines={1}>Interest Due Today : {item['Interest Due Today']}</Text>
                                        <Text note numberOfLines={1}>Unutilized : {item['Unutilized Amount']}</Text>
                                        <Text note numberOfLines={1}>Commited : {item['Tranche Amount']}</Text>
                                    </Body>
                                    <Right>
                                        {/* <Button onPress={() => this.props.clickhandler(item)}>
                                            <Icon name="arrow-down" />
                                        </Button> */}
                                    </Right>
                                </ListItem>
                            </List>
                        )
                    }) : <Text>Do Data Found</Text>}
                </Content>
            </Container>

        );
    }
}