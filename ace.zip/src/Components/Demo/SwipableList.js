import React from 'react';
import { ListView } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import GroupExposure from './GroupExposure';
import groupExposure from '../../../src/groupExposure.json';
// import { Container, Header, Content, Card, CardItem, Text, Body, Button } from "native-base";
import { Container, Content, List, Button, Icon } from 'native-base';
import axios from 'axios';

export default class Exposure extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };
    constructor() {
        super();
        this.ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
        this.state = {
            groupExposure: []
        }
    }
    componentDidMount() {

        this.setState({
            groupExposure: groupExposure
        })
    }
    render() {
        const ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
        return (
            <Container>
                <Content>
                    {<List
                        leftOpenValue={75}
                        rightOpenValue={-75}
                        dataSource={this.ds.cloneWithRows(this.state.groupExposure)}
                        renderRow={(item, i) =>
                            <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />}
                        renderLeftHiddenRow={item =>
                            <Button full onPress={() => alert(item)}>
                                <Icon active name="information-circle" />
                            </Button>}
                        renderRightHiddenRow={(item, secId, rowId, rowMap) =>
                            <Button full danger onPress={() => alert(item)}>
                                <Icon active name="trash" />
                            </Button>}
                    />}

                    {/* {this.state.groupExposure.map((item, i) => {
                        return (
                            <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />
                        )
                    })} */}
                </Content>
            </Container>
        );
    }

    _showMoreApp = (d) => {
        this.props.navigation.navigate('IssuerExposure', {
            group: d
        });
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}