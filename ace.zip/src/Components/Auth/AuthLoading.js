// import { AsyncStorage } from "react-native";
import AsyncStorage from '@react-native-community/async-storage';
import axios from 'axios';
export const USER_KEY = "auth-demo-key";

export const onSignIn = (d) => {
  return axios.post('http://172.16.1.89:211/api/login', { UserName: d.userName, Password: d.password })
    .then(function (response) {
      console.log(response);
      AsyncStorage.setItem(USER_KEY, "true");

    })
    .catch(function (error) {
      console.log(error);
    });
};

export const onSignOut = () => AsyncStorage.removeItem(USER_KEY);

export const isSignedIn = () => {
  return new Promise((resolve, reject) => {
    AsyncStorage.getItem(USER_KEY)
      .then(res => {
        if (res !== null) {
          resolve(true);
        } else {
          resolve(false);
        }
      })
      .catch(err => reject(err));
  });
};
