import React from 'react';
import { View, ActivityIndicator, StatusBar, SafeAreaView, Alert } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { isSignedIn, extendValidity } from './AuthLoading';
const USER_KEY = "auth-key";
export default class InitAuth extends React.Component {
    constructor() {
        super();
        this._bootstrapAsync();
    }
    // Fetch the token from storage then navigate to our appropriate place
    _bootstrapAsync = async () => {
        try {
            const userToken = await isSignedIn();
            if (userToken) {
                extendValidity().then((res) => {
                    if (res)
                        this.props.navigation.navigate('App');
                    else
                        this.props.navigation.navigate('Auth');
                });
            }
            else {
                this.props.navigation.navigate('Auth');
            }
        } catch (err) {
            Alert.alert("Oops! [InitAuth]", err);
        };

    };
    // Render any loading content that you like here
    render() {
        return (
            <SafeAreaView>
                <View>
                    <ActivityIndicator />
                    <StatusBar barStyle="default" />
                </View>
            </SafeAreaView>
        );
    }
}