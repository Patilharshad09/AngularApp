import axios from 'axios';
export const USER_KEY = "auth-key";
export const API_URL = "http://www.testapi.akgroup.co.in:211/api/";

export const Post = (param, data) => {
    var props = {
        'name': param, 'value': data
    };
    var d = { "value": JSON.stringify(props) };
    return axios.post(API_URL + 'post', d)
        .then(function (response) {
            return response.data;
        })
        .catch(function (error) {
            return null;
        });
};