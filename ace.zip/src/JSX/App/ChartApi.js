﻿/**/
var Chartobj = { ChartTitle: '', xTitleValue: '', xGLWidth: 1, yTitleValue: '', yGLWidth: 1, enableMouseTracking: true, DataArray: [], EnableExporting: false, PlotYAxisOnRight: true,category:[] };
var DualAxisChart = { ChartTitle: '', xTitleValue: '', xGLWidth: 0, yTitleValue: [], yGLWidth: 0, enableMouseTracking: true, DataArray: [], EnableExporting: false}
var DatetimeFormat = ['%H:%M:%S.%L', '%H:%M:%S', '%H:%M', '%e. %b', '%b \'%y', '%Y'];
function CallChart(ParamValue, elementId) {
    Highcharts.chart(elementId, {
        title: {
            text: ParamValue.ChartTitle,
             align: 'right',
             style: {
                fontSize: "14px"
            }
        },
        chart: {
            type: 'area'
        },
        exporting: { enabled: ParamValue.EnableExporting },
        xAxis: {
            title: {
                text: ParamValue.xTitleValue
            },
            categories: ParamValue.category ,
            //tickInterval: ParamValue.xtickInterval,
            gridLineWidth: ParamValue.xGLWidth //Remove xAxis lines
        },

        yAxis: {
            title: {
                text: ParamValue.yTitleValue
            },
            opposite: !ParamValue.PlotYAxisOnRight,
            //tickInterval: ytickInterval,
            gridLineWidth: ParamValue.yGLWidth //Remove yAxis lines
        },

        plotOptions: {
            series: {
                animation: {
                    duration: 2000
                },
                lineWidth: 6,
                marker: {
                     radius: 10
                      //symbol: 'url(https://www.highcharts.com/samples/graphics/sun.png)'
                },
                fillColor: {
                    linearGradient: [0, 0, 0, 300],
                    stops: [
                        [0, Highcharts.getOptions().colors[0]],
                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                    ]
                },   
                enableMouseTracking: ParamValue.enableMouseTracking
            },

        },

        series: ParamValue.DataArray
    });
}
