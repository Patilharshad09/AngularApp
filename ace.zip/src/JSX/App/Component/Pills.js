class Pills extends React.Component {
    constructor(props) {
        super(props);

    }
    generateheader = () => {
        var data = this.props.data;
        return data.map(function (key, i) {
            return <li key={i} className={key.class} >
                <a href={"#tab" + key.name + i} data-toggle="pill">{key.name}</a>
            </li>
        });
    }
    generateContent = () => {
        var data = this.props.data;
        return data.map(function (key, i) {
            var Component = window[key.content];
            var props = { data: this.props.data, dataUrl: this.props.dataUrl }
            return <div key={i} className={`tab-pane ${key.class}`} id={"tab" + key.name + i}>
                <Component {...props} />
            </div>

        });
    }
    render = () => {
        var headers = this.generateheader();
        var contenttabs = this.generateContent();
        return (
            <div>
                <ul className="nav nav-pills small" id={"tabs" + this.props.pillsId}>
                    {headers}
                </ul>
                <div className="tab-content">
                    {contenttabs}
                </div>
            </div>
        );
    }
}