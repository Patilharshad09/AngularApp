﻿// var HTable = React.createClass({
//     getInitialState: function () {
//         return {
//             d: []
//         }
//     },
//     componentWillMount: function () {
//         $.ajax({
//             url: "/data/datafeed/summary/" + this.props.dataUrl + "/1",
//             type: 'GET',
//             cache: false,
//             dataType: 'json',
//             success: function (response) {
//                 this.setState({
//                     d: JSON.parse(response)
//                 });
//                 console.log(this.state.d);
//             }.bind(this),
//             error: function (error) {
//                 alert("fail - " + error);
//             }
//         });
//     },
    
// });
// ReactDOM.render(<HTable dataUrl='GetCPDeals' />, document.getElementById('cpdeals'));
// ReactDOM.render(<HTable dataUrl='GetCDDeals' />, document.getElementById('cddeals'));

class HorizontalTable extends React.Component{
    constructor(){
        super();
    }
    render= ()=> {
        var headerComponents = this.generateHeaders(),
            rowComponents = this.generateRows();
        return (
            <table className="table table-hover table-condensed small" data-toggle="table">
                <thead><tr>{headerComponents}</tr></thead>
                <tbody>{rowComponents}</tbody>
            </table>
        );
    }
    generateHeaders= ()=> {
        if (this.props.data.length > 0) {
            var cols = Object.keys(this.props.data[0]);
            return cols.map(function (key, i) {
                return <th data-sortable="true" key={i}>{key}</th>;

            });
        }
    }
    generateRows = ()=> {
        if (this.props.data.length > 0) {
            var data = this.props.data;
            var cols = Object.keys(data[0]);
            return data.map(function (item, i) {
                var cells = cols.map(function (colData, i) {
                    return <td key={i}> {item[colData]} </td>;
                });
                return <tr key={i}>{cells}</tr>;
            });
        }
    }

}