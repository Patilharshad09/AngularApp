﻿class VerticalTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }
    update() {
        console.log('Updating State');
    }
    componentWillMount() {
        console.log('ComponentWillMount');
        if (!this.props.data) {
            window.getdata('summary/' + this.props.dataUrl).then(function (response) {
                this.setState({
                    data: JSON.parse(response)
                });
            }.bind(this));
        }
        else {
            this.setState({
                data: this.props.data
            });
        }

    }
    componentDidMount() {
        console.log('ComponentDidMount');
    }
    shouldComponentUpdate() {
        console.log('ShouldComponentUpdate');
        return true;
    }
    componentWillReceiveProps = (nextProps) => {
        console.log('ComponentWillRecieveProps');
    }
    componentWillUpdate() {
        console.log('ComponentWillUpdate');
    }
    componentDidUpdate() {
        console.log('ComponentDidUpdate');
    }
    componentWillUnmount() {
        console.log('componentWillUnmount');
    }
    generateRows = () => {
        if (this.state.data.length > 0) {
            var data = [];
            data = this.state.data;
            var cols = Object.keys(data[0]);
            var keyval = this.props.dataUrl;
            return data.map(function (item, i) {
                var cells = cols.map(function (colData, j) {
                    return <tr key={keyval + j + 'row'}><td key={keyval + i + 'column0' + j}>{colData}</td><td key={keyval + i + 'column1' + j}>{item[colData]}</td></tr>
                });
                return <tbody key={keyval + 'body'}>{cells}</tbody>;
            });
        }
    }
    render = () => {
        var rowComponents = this.generateRows();
        //var keyVal = Math.ceil(Math.random() * 100).toString();
        return (
            <table key={this.props.dataUrl} className="table table-hover small" data-toggle="table">
                {rowComponents}
            </table>
        );
    }
}
