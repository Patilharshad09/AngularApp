class Charts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: {}
        }
    }
    update() {
        console.log('Updating State');
    }
    componentWillMount() {
    }
    componentDidMount() {
        this.drow(this.props)
    }
    shouldComponentUpdate() {
        console.log('ShouldComponentUpdate');
        return true;
    }
    componentWillUpdate() {
        console.log('ComponentWillUpdate');
    }
    componentDidUpdate() {
        console.log('ComponentDidUpdate');
    }
    componentWillUnmount() {
        this.chart.destroy();
    }
    componentWillReceiveProps(nextProps, nextState) {
        this.chart.destroy()
        this.drow(nextProps)
    }
    drow(props) {
        this.chart = Highcharts.chart(this.container, {
            chart: {
                type: props.data.charttype
            },
            title: {
                text: props.data.title
            },
            xAxis: {
                categories: ['1750', '1800', '1850', '1900', '1950', '1999', '2050'],
                tickmarkPlacement: 'on',
                title: {
                    enabled: false
                }
            },
            yAxis: {
                title: {
                    text: 'Percent'
                }
            },
            tooltip: {
                pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.percentage:.1f}%</b> ({point.y:,.0f} millions)<br/>',
                split: true
            },
            plotOptions: {
                area: {
                    stacking: 'percent',
                    lineColor: '#ffffff',
                    lineWidth: 1,
                    marker: {
                        lineWidth: 1,
                        lineColor: '#ffffff'
                    }
                }
            },
            series: props.data.data
        })
    }
    render = () => {
        return <div className="chart" ref={ref => this.container = ref} />
    }
}