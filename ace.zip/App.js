import { createSwitchNavigator, createAppContainer } from 'react-navigation';
import InitAuth from './src/Components/Auth/initAuth';
import { AuthRoutes } from './src/Routes/AuthRoutes';
import { AppRoutes } from './src/Routes/AppRoutes';

export default createAppContainer(createSwitchNavigator(
    {
        AuthLoading: InitAuth,
        App: AppRoutes,
        Auth: AuthRoutes,
    },
    {
        initialRouteName: 'AuthLoading',
        headerMode: 'none'
    }
));