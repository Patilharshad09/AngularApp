import { createSwitchNavigator, createStackNavigator, createAppContainer, createDrawerNavigator, createBottomTabNavigator } from 'react-navigation';
import DashBoard from './src/Components/Private/DashBoard';
import Notifications from './src/Components/Private/Notifications';

import SignIn from './src/Components/Auth/SignIn';
import InitAuth from './src/Components/Auth/initAuth';
const AppStack = createDrawerNavigator({ DashBoard: DashBoard, Notifications: Notifications });
const AuthStack = createStackNavigator({ SignIn: SignIn });

export default createAppContainer(createSwitchNavigator(
    {
        AuthLoading: InitAuth,
        App: AppStack,
        Auth: AuthStack,
    },
    {
        initialRouteName: 'AuthLoading',
        headerMode: 'none'
    }
));
