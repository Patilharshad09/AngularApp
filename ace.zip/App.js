import { createSwitchNavigator, createStackNavigator, createAppContainer, createDrawerNavigator, createBottomTabNavigator } from 'react-navigation';
import DashBoard from './src/Components/Private/DashBoard';
import Notifications from './src/Components/Private/Notifications';
import Exposure from './src/Components/Private/Exposure';
import IssuerExposure from './src/Components/Private/IssuerExposure';
import IssuerSummary from './src/Components/Private/IssuerSummary'
import SignIn from './src/Components/Auth/SignIn';
import InitAuth from './src/Components/Auth/initAuth';
const AppStack = createDrawerNavigator({
    Exposure: Exposure, IssuerExposure: IssuerExposure, IssuerSummary: IssuerSummary,
    DashBoard: DashBoard, Notifications: Notifications
});
const AuthStack = createStackNavigator({ SignIn: SignIn });

export default createAppContainer(createSwitchNavigator(
    {
        AuthLoading: InitAuth,
        App: AppStack,
        Auth: AuthStack,
    },
    {
        initialRouteName: 'App',
        headerMode: 'none'
    }
));
