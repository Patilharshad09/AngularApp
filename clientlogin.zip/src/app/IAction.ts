export interface IACtion{
    inputData: any;
}