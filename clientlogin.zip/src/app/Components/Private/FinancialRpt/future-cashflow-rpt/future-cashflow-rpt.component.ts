import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-future-cashflow-rpt',
  templateUrl: './future-cashflow-rpt.component.html',
  styleUrls: ['./future-cashflow-rpt.component.css']
})
export class FutureCashflowRptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
