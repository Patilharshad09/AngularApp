import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FutureCashflowRptComponent } from './future-cashflow-rpt.component';

describe('FutureCashflowRptComponent', () => {
  let component: FutureCashflowRptComponent;
  let fixture: ComponentFixture<FutureCashflowRptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FutureCashflowRptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FutureCashflowRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
