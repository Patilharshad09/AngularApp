import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-income-expense-rpt',
  templateUrl: './income-expense-rpt.component.html',
  styleUrls: ['./income-expense-rpt.component.css']
})
export class IncomeExpenseRptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
