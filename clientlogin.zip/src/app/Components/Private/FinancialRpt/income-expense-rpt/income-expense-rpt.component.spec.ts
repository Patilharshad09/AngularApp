import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncomeExpenseRptComponent } from './income-expense-rpt.component';

describe('IncomeExpenseRptComponent', () => {
  let component: IncomeExpenseRptComponent;
  let fixture: ComponentFixture<IncomeExpenseRptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncomeExpenseRptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncomeExpenseRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
