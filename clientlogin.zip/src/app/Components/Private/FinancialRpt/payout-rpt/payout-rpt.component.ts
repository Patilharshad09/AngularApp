import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payout-rpt',
  templateUrl: './payout-rpt.component.html',
  styleUrls: ['./payout-rpt.component.css']
})
export class PayoutRptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
