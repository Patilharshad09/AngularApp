import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayoutRptComponent } from './payout-rpt.component';

describe('PayoutRptComponent', () => {
  let component: PayoutRptComponent;
  let fixture: ComponentFixture<PayoutRptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayoutRptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayoutRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
