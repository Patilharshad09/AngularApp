import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-transaction-rpt',
  templateUrl: './transaction-rpt.component.html',
  styleUrls: ['./transaction-rpt.component.css']
})
export class TransactionRptComponent implements OnInit {

  constructor(private http: HttpClient) { }
  configUrl = 'http://localhost:57067/api/values';

  postData() {
    this.http.get(this.configUrl).subscribe((d) => {
      console.log(d);
    });
  }

  ngOnInit(): void {
    this.postData();
  }

}
