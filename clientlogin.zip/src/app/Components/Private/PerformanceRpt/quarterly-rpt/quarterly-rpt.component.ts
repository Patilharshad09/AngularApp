import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quarterly-rpt',
  templateUrl: './quarterly-rpt.component.html',
  styleUrls: ['./quarterly-rpt.component.css']
})
export class QuarterlyRptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
