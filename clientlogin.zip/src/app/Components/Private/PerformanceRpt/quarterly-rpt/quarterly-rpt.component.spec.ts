import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuarterlyRptComponent } from './quarterly-rpt.component';

describe('QuarterlyRptComponent', () => {
  let component: QuarterlyRptComponent;
  let fixture: ComponentFixture<QuarterlyRptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuarterlyRptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuarterlyRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
