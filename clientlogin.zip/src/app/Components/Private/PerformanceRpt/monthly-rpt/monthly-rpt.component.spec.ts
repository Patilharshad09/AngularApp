import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyRptComponent } from './monthly-rpt.component';

describe('MonthlyRptComponent', () => {
  let component: MonthlyRptComponent;
  let fixture: ComponentFixture<MonthlyRptComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyRptComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyRptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
