import { Component, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-monthly-rpt',
  templateUrl: './monthly-rpt.component.html',
  styleUrls: ['./monthly-rpt.component.css']
})
export class MonthlyRptComponent implements OnInit {
  @Input() currentUser = null;
  constructor(private http: HttpClient, private authService: AuthService) { }
  configUrl = 'http://localhost:57067/api/values';

  postData() {
    this.http.get(this.configUrl).subscribe((d) => {
      console.log(d);
    });
  }

  ngOnInit(): void {
    setTimeout(
      () => this.authService.currentUser.subscribe(x => this.currentUser = x)
    );

    this.postData();
  }

}
