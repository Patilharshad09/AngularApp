import { Component, OnInit, Output, EventEmitter, Input, HostListener } from '@angular/core';
import { AuthService } from 'src/app/Services/auth.service';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { User } from '../../Public/login/User';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Output() toggleHandler = new EventEmitter();
  @Input() currentUser = null;
  private currentUserSubject: BehaviorSubject<User>;

  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
    setTimeout(
      () => this.authService.currentUser.subscribe(x => this.currentUser = x)
    );
  }

  logout() {
    this.authService.logout();
  }

  toggleClick() {
    this.toggleHandler.emit({});
  }
}
