import { Component, OnInit, Input, HostListener } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  @Input() shrink = false;
  screenHeight: number;
  screenWidth: number;
  @Input() currentUser = null;
  constructor() {
    this.onResize();
  }

  ngOnInit(): void {
  }
  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    this.screenHeight = window.innerHeight;
    this.screenWidth = window.innerWidth;
  }

}
