import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/Services/login.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { first, delay } from 'rxjs/operators';
import { SnackbarService } from 'ngx-snackbar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  submitted = false;
  returnUrl: string;
  error = '';
  loading = false;
  username = '';
  password = '';

  constructor(private loginService: LoginService,
              private router: Router,
              private snackbarService: SnackbarService,
              private activatedRoute: ActivatedRoute,
              private authService: AuthService) {

    if (this.authService.currentUserValue) {
      this.router.navigate(['/monthly-performance-rpt']);
    }
  }
  ngOnInit(): void {
    localStorage.removeItem('currentUser');
    this.authService.logout();
    this.returnUrl = this.activatedRoute.snapshot.queryParams.returnUrl || '/login';
  }
  Login(): void {
    this.submitted = true;
    if (this.username === '' || this.password === '') {
      this.snackbarService.add({
        msg: '<b>ERROR:</b>',
        action: {
          text: 'Invalid Credentials',
        },
        customClass: ['snack-error'],
      });
    } else {
      this.loading = true;
      this.authService.login(this.username, this.password)
        .pipe(first(), delay(0))
        .subscribe(
          result => {
            if (result !== '1') {
              this.snackbarService.add({
                msg: 'Error!',
                action: {
                  text: 'Invalid Credentials',
                },
              });
              this.router.navigate(['/']);

            } else if (result === '1') {
              this.snackbarService.add({
                msg: 'Success!',
                action: {
                  text: 'Login Successfull',
                },
              });
              this.router.navigate(['/monthly-performance-rpt']);
            }
          },
          err => {
            this.error = err;
            console.log(JSON.stringify(this.error));
            this.snackbarService.add({
              msg: 'ERROR!',
              action: {
                text: 'Something went wrong',
              },
            });
            this.loading = false;
          }
        );
    }
  }
}
