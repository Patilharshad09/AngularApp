export class User {
    id: string;
    UserName: string;
    Password: string;
    token?: string;
}
