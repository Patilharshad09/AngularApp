import { Type } from '@angular/core';

export class ActionType {
    constructor(public component: Type<any>) {}
  }