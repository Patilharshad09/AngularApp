import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DataFeedService } from './data-feed.service';
import { User } from '../Components/Public/login/User';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(public dataFeedService: DataFeedService) { }
  inputParam: any;
  currentUser: User;
  saveFormData(actionName, username, password): Observable<any> {

    this.inputParam = {
      user: username,
      pass: password
    };
    return this.dataFeedService.postData(actionName, this.inputParam);
  }

}
