import { Injectable } from '@angular/core';
import { User } from '../Components/Public/login/User';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { LoginService } from './login.service';
import { UtilityService } from './utility.service';
import { Router } from '@angular/router';
import { HubConnection } from '@aspnet/signalr';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  d: any = [];
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(private http: HttpClient, private loginService: LoginService,
    private utilityService: UtilityService, private router: Router) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }
  public setCurrentUser(user: User) {
    this.currentUserSubject.next(user);
  }
  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }
  login(username: string, password: string) {

    this.d = {
      id: '403C25B9-EADC-4F73-8DC7-744E0CC0462A',
      UserName: username,
      Password: password,
      token: '403C25B9-EADC-4F73-8DC7-744E0CC0462A'
    };

    return this.loginService.saveFormData('GET_LOGIN', username, password)
      .pipe(map(user => {
        console.log(user);
        localStorage.setItem('currentUser', JSON.stringify(this.d));
        sessionStorage.setItem('currentUser', JSON.stringify(this.d));
        this.currentUserSubject.next(this.d);
        return user;
      }));

  }
  logout() {
    sessionStorage.removeItem('currentUser');
    localStorage.removeItem('currentUser');
    if (this.currentUserSubject.value) {
      this.utilityService.removeUserGroup(this.currentUserSubject.value.UserName).then(d => {
        this.currentUserSubject.next(null);
      });
    }
  }
}
