import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DataFeedService {
  apidata: any;
  props = null;
  formData = null;
  headers = null;

  constructor(private http: HttpClient) { }
  configUrl = 'http://localhost:57067/api/values';

  postData(Action: string, Input: any): Observable<any> {
    this.props = {
      action: Action,
      input: Input,
    };
    this.formData = { VALUE: JSON.stringify(this.props) };
    console.log(this.formData);
    this.headers = new HttpHeaders();
    this.headers = this.headers.append('userId', '403C25B9-EADC-4F73-8DC7-744E0CC0462A');
    this.headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
    return this.http.post(this.configUrl, this.formData, { headers: this.headers });
    // console.log(this.apidata);
    // return this.apidata;
  }
}
