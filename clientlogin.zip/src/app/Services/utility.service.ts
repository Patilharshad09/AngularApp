import { Injectable, EventEmitter } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { Observable, Subject } from 'rxjs';
import { User } from '../Components/Public/login/User';


@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  public hubConnection: HubConnection;
  connectionEstablished = new EventEmitter<boolean>();
  currentUser: User;
  private groupStateSource = new Subject<boolean>();
  groupState$ = this.groupStateSource.asObservable();

  groupDestroyed(state: boolean) {
    this.groupStateSource.next(state);
  }
  startConnection(): Promise<any> {
    this.hubConnection = new HubConnectionBuilder().withUrl('https://localhost:44376/feed').build();

    this.hubConnection.on('groupDestroyed', (d) => {
      this.groupDestroyed(false);
    });
    return this.hubConnection.start();

  }
  async addUserGroup(username: string) {
    if (this.hubConnection.state === 0) {
      await this.startConnection().then(d => {
        this.hubConnection.send('createUserGrp', username);
      });
    } else {
      await this.hubConnection.send('createUserGrp', username)
        .then(d => { console.log(d); })
        .catch(err => console.error(`could not create user group ${err}`));
    }
  }

  async removeUserGroup(username: string) {
    await this.startConnection().then(d => {
      this.hubConnection.send('destroyUserGrp', username);
    });
  }

  closeConnection(): Promise<any> {
    return this.hubConnection.stop().then(d => {
      console.log('Connection closed');
    }).catch(err => {
      console.error(`Error : ${err}`);
    });
  }
}
