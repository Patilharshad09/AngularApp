import { Component, HostListener, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from './Services/auth.service';
import { User } from './Components/Public/login/User';
import { UtilityService } from './Services/utility.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'clientlogin';
  shrink = false;
  currentUser: User;

  toggleHandler() {
    this.shrink = !this.shrink;
  }
  ngOnInit(): void { }
  constructor(
    private router: Router, private activatedRoute: ActivatedRoute,
    private authService: AuthService, private utilityService: UtilityService
  ) {
    this.utilityService.startConnection().then(d => {
      this.currentUser = this.authService.currentUserValue;
      if (!this.currentUser) {
        this.router.navigateByUrl('/login');
      }
    });
    this.authService.currentUser.subscribe((x) => {
      this.currentUser = x;
      if (this.currentUser) {
        this.utilityService.addUserGroup(this.currentUser.UserName);
      } else {
        this.router.navigate(['/login']);
      }
    });
    this.utilityService.groupState$.subscribe((x) => {
      if (!x) {
        this.authService.setCurrentUser(null);
        this.router.navigate(['/login']);
      }
    });
  }
}
