import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './Components/Public/login/login.component';
import { MonthlyRptComponent } from './Components/Private/PerformanceRpt/monthly-rpt/monthly-rpt.component';
import { QuarterlyRptComponent } from './Components/Private/PerformanceRpt/quarterly-rpt/quarterly-rpt.component';
import { TransactionRptComponent } from './Components/Private/FinancialRpt/transaction-rpt/transaction-rpt.component';
import { IncomeExpenseRptComponent } from './Components/Private/FinancialRpt/income-expense-rpt/income-expense-rpt.component';
import { PayoutRptComponent } from './Components/Private/FinancialRpt/payout-rpt/payout-rpt.component';
import { FutureCashflowRptComponent } from './Components/Private/FinancialRpt/future-cashflow-rpt/future-cashflow-rpt.component';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth.guard';


const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: AppComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'monthly-performance-rpt',
    canActivate: [AuthGuard],
    component: MonthlyRptComponent
  },
  {
    path: 'quarterly-performance-rpt',
    component: QuarterlyRptComponent
  },
  {
    path: 'transaction-financial-rpt',
    component: TransactionRptComponent
  },
  {
    path: 'income-expense-financial-rpt',
    component: IncomeExpenseRptComponent
  },
  {
    path: 'payout-financial-rpt',
    component: PayoutRptComponent
  },
  {
    path: 'future-cashflow-financial-rpt',
    component: FutureCashflowRptComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
