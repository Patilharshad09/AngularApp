import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { LoginComponent } from './Components/Public/login/login.component';
import { SignupComponent } from './Components/Public/signup/signup.component';
import { ForgotPasswordComponent } from './Components/Public/forgot-password/forgot-password.component';
import { HeaderComponent } from './Components/Shared/header/header.component';
import { SidebarComponent } from './Components/Shared/sidebar/sidebar.component';
import { MonthlyRptComponent } from './Components/Private/PerformanceRpt/monthly-rpt/monthly-rpt.component';
import { QuarterlyRptComponent } from './Components/Private/PerformanceRpt/quarterly-rpt/quarterly-rpt.component';
import { TransactionRptComponent } from './Components/Private/FinancialRpt/transaction-rpt/transaction-rpt.component';
import { IncomeExpenseRptComponent } from './Components/Private/FinancialRpt/income-expense-rpt/income-expense-rpt.component';
import { PayoutRptComponent } from './Components/Private/FinancialRpt/payout-rpt/payout-rpt.component';
import { FutureCashflowRptComponent } from './Components/Private/FinancialRpt/future-cashflow-rpt/future-cashflow-rpt.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DataFeedService } from './Services/data-feed.service';
import { LoginService } from './Services/login.service';
import { AuthService } from './Services/auth.service';
import { JWTInterceptor } from './jwt.interceptor';
import {SnackbarModule} from 'ngx-snackbar';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    ForgotPasswordComponent,
    HeaderComponent,
    SidebarComponent,
    MonthlyRptComponent,
    QuarterlyRptComponent,
    TransactionRptComponent,
    IncomeExpenseRptComponent,
    PayoutRptComponent,
    FutureCashflowRptComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    SnackbarModule.forRoot()
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JWTInterceptor,
      multi: true
    },
    DataFeedService, LoginService, AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
