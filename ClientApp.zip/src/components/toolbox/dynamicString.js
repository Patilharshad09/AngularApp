﻿import React from 'react';

class App extends React.Component {

    constructor() {
        super();
        this.state = {
            description: document.createTextNode('<li data-item-id="1156" id="key-stats-1156" class="span4 news-thumbnail"><article class="news_thumbnail news_item_truncated">          <div class="news-time-wrap">            <i class="icon-calendar"></i>&nbsp;Posted&nbsp;<time datetime="2015-08-07" pubdate="pubdate">2015-08-07</time>          </div>          <header>            <h5><a href="/bonds/news_item/1156" data-remote="true" data-target="#newsItem">Asian mkts in red; US Jul jobs data eyed</a></h5>          </header>          Cogencis          <p> <br> MUMBAI - Asian equities were in the red early in todays session on cues<br>from US equities that ended lower on caution ahead of the non-farm payrolls<br>data that will be published later today.<br> US... <a href="/bonds/news_item/1156" data-remote="true" data-target="#newsItem">Read more &gt;&gt;</a></p>        </article>        </li>')
            //'&lt;p&gt; &lt;strong&gt;MUMBAI - Trade in Asian equities was mixed tracking US and European&lt;/strong&gt;&lt;/p&gt; &lt;p&gt;&lt;em&gt;MUMBAI - Trade in Asian equities was mixed tracking US and European&lt;/em&gt;&lt;/p&gt; &lt;p&gt;&lt;u&gt;MUMBAI - Trade in Asian equities was mixed tracking US and European&lt;/u&gt;&lt;/p&gt;'
        }
            
    }

    htmlDecode(input) {
        var e = document.createElement('div');
        e.innerHTML = input;
        return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
    }

    render() {
        const { description } = this.state;
        return (
            <div dangerouslySetInnerHTML={{ __html: description }} ></div>
            //<div dangerouslySetInnerHTML={{ __html: this.htmlDecode(description) }} ></div>
        );
    }
}

ReactDOM.render(
    <App />,
    document.getElementById('root')
);
