﻿import React from 'react';

var cols = [
    { name: 'Market', class: 'active', content: 'VerticalTable', dataUrl: 'GetKeyIndicators_RBI',data:null },
    { name: 'RBI', class: '', content: 'VerticalTable', dataUrl: 'GetKeyIndicators_Market', data: null},
    { name: 'Economy', class: '', content: 'VerticalTable', dataUrl: 'GetKeyIndicators_Economy', data: null}
    
];

const title = 'Historic and Estimated Worldwide Population Distribution by Region';
const GSEC = [{
  name: 'GSEC',
  data: [502, 635, 809, 947, 1402, 3634, 5268]
}];
const LAF = [{
  name: 'LAF',
  data: [106, 107, 111, 133, 221, 767, 1766]
}];
const CBLO = [{
  name: 'CBLO',
  data: [140, 203, 276, 408, 547, 729, 628]
}]; 
const INFLATION = [{
  name: 'INFLATION',
  data: [163, 203, 276, 408, 547, 729, 628]
}]; 
const IIP =[{
  name: 'IIP',
  data: [18, 31, 54, 156, 339, 818, 1201]
}]; 
const GDP =[{
  name: 'GDP',
  data: [2, 2, 2, 6, 13, 30, 46]
}];

var chartdata = [
    { name: 'GSEC', class: 'active', content: 'Charts', dataUrl: '',data:{ title:title, data:GSEC,charttype:'line'} },
    { name: 'LAF', class: '', content: 'Charts', dataUrl: '', data:{ title:title, data:LAF,charttype:'column'} },
    { name: 'CBLO', class: '', content: 'Charts', dataUrl: '',data:{ title:title, data:CBLO,charttype:'line'} },
    { name: 'INFLATION', class: '', content: 'Charts', dataUrl: '', data:{ title:title, data:INFLATION,charttype:'line'} },
    { name: 'IIP', class: '', content: 'Charts', dataUrl: '',data:{ title:title, data:IIP,charttype:'line'} },
    { name: 'GDP', class: '', content: 'Charts', dataUrl: '', data:{ title:title, data:GDP,charttype:'line'} }
];


ReactDOM.render(<KeyIndicatorSection data={cols} pillsId={'KeyIndicators'} />, document.getElementById('keyindicator'));
ReactDOM.render(<KeyStats data={chartdata} pillsId={'KeyStats'} />, document.getElementById('KeyStats'));
// ReactDOM.render(
//   <Charts title={title} data={data} />,
//   document.getElementById('KeyStats')
// )