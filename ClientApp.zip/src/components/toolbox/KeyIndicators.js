﻿import React from 'react';

class KeyIndicators extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }
    update() {
        console.log('Updating State');
        //window.getdata('Updating State');
    }
    componentWillMount() {
        console.log('ComponentWillMount');
        window.getdata('summary/' + this.props.dataUrl).then(function (response) {
            this.setState({
                data: JSON.parse(response)
            });
        }.bind(this));
    }
    componentDidMount() {
        console.log('ComponentDidMount');
        //window.getdata('summary/GetCPDeals/1').then(function (data) {
        //    console.log(data);
        //});
    }
    shouldComponentUpdate() {
        console.log('ShouldComponentUpdate');
        //window.getdata('ShouldComponentUpdate');
        return true;
    }
    componentWillReceiveProps = (nextProps) => {
        console.log('ComponentWillRecieveProps');
        //window.getdata('ComponentWillRecieveProps');
    }
    componentWillUpdate() {
        console.log('ComponentWillUpdate');
        //window.getdata('ComponentWillUpdate');
    }
    componentDidUpdate() {
        console.log('ComponentDidUpdate');
        //window.getdata('ComponentDidUpdate');
    }
    componentWillUnmount() {
        console.log('componentWillUnmount');
        //window.getdata('componentWillUnmount');
    }
    render() {
        let Component = window[this.props.content];
        var props = { data: this.state.data, dataUrl: this.props.dataUrl };
        return <Component {...props} />
        //return (
        // //   let Component = Components[comp.name];
	      	//	//return <Component key={comp.name} />
        // //   <VerticalTable  dataUrl={this.props.dataUrl} data={this.state.data} />
        //);
    }
}