﻿function getdata(dataUrl) {
    
    return $.ajax({
        url: "/data/datafeed/" + dataUrl,
        type: 'GET',
        cache: true,
        dataType: 'json',
        success: function (response) {
            return response;
        },
        error: function (error) {
            return null;
        }
    });
}