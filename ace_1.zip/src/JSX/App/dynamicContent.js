﻿var cols = [
    { name: 'Market', class: 'active', content: 'KeyIndicators', dataUrl: 'GetKeyIndicators_RBI' },
    { name: 'RBI', class: '', content: 'KeyIndicators', dataUrl: 'GetKeyIndicators_Market'  },
    { name: 'Economy', class: '', content: 'KeyIndicators', dataUrl: 'GetKeyIndicators_Economy' }];

class PageContent extends React.Component {
    constructor() {
        super();
        this.renderElement = this.renderElement.bind(this);
        this.recurseElements = this.recurseElements.bind(this);
    }
    renderElement(item) {
        var components = {
            'KeyIndicators': KeyIndicators
        }
        return React.createElement(components[item.content], item);
    }
    recurseElements(item) {
        return (Object.prototype.toString.call(item) === '[object Array]')
            ? item.map(this.recurseElements)
            : this.renderElement(item);
    }
    render() {
        var content = [];

        for (var i = 0; i < this.props.data.length; i++) {
            content.push(this.recurseElements(this.props.data[i]));
        }
        return React.createElement("div", { id: "content" }, content)
    }
}

ReactDOM.render(<PageContent data={cols} />, document.getElementById('content'));