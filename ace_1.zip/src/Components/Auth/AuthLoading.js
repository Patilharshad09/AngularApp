import AsyncStorage from '@react-native-community/async-storage';
import axios from 'axios';
import { Alert } from 'react-native';
export const USER_KEY = "auth-key";
export const API_URL = "http://www.testapi.akgroup.co.in:211/api/";

storeAsyncData = async (key, value) => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    Alert.alert("Oops! [storeAsyncData]", err);
  }
}
setValidity = (date) => {
  date.setDate(date.getDate() + 7);
}
export const extendValidity = async () => {
  try {
    let value = await AsyncStorage.getItem(USER_KEY);
    if (value !== null) {
      var userToken = JSON.parse(value);
      if (userToken.hasOwnProperty('validity')) {
        if (userToken.hasOwnProperty('validity')) {
          userToken.validity = new Date();
          setValidity(userToken.validity);
          await storeAsyncData(USER_KEY, userToken);
          return true;
        }
      }
      else {
        return false;
      }

    } else {
      return false;
    }
  } catch (err) {
    Alert.alert("Oops! [extendValidity]", err);
    return false;
  };

}

export const onSignIn = (d) => {
  try {
    var props = {
      UserName: d.userName,
      Password: d.passWord,
      AuthType: d.authType
    }
    return axios.post(API_URL + 'feed/ValidateUser', props)
      .then(function (response) {
        onSignOut().then((res) => {
          response.data[0].validity = new Date();
          setValidity(response.data[0].validity);
          storeAsyncData(USER_KEY, response.data[0]).then((res) => {
            return response.data;
          });
        });
      })
      .catch(function (error) {
        return error;
      });
  } catch (err) {
    Alert.alert("Oops! [onSignIn]", err);
    return null;
  };
};

export const onVerifyUser = (d) => {
  var props = {
    UserName: d.userName,
    Password: null,
    AuthType: null
  }
  // var data = { "value": JSON.stringify(props) }
  return axios.post(API_URL + 'feed/UserCheck', props)
    .then(function (response) {
      return response.data;
    })
    .catch(function (error) {
      return error;
    });
};
export const onGeneratePassKey = (param, data) => {
  try {
    var props = {
      'name': param, 'value': data
    };
    var d = { "value": JSON.stringify(props) };
    return axios.post(API_URL + 'post', d)
      .then(function (response) {
        return response.data;
      })
      .catch(function (error) {
        return null;
      });
  } catch (err) {
    Alert.alert("Oops! [onGeneratePassKey]", err);
    return false;
  };
};

export const onSignOut = async () => await AsyncStorage.removeItem(USER_KEY);

export const isSignedIn = async () => {
  try {
    let value = await AsyncStorage.getItem(USER_KEY);
    if (value !== null) {
      var token = JSON.parse(value);
      if (token.hasOwnProperty('validity')) {
        if (Date.parse(token.validity) > new Date()) {
          return true;
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }

    } else {
      return false;
    }

  } catch (err) {
    Alert.alert("Oops! [onGeneratePassKey]", err);
    return false;
  };
}