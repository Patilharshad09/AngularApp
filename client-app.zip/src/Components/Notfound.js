import React from 'react';
class Notfound extends React.Component {
    render() {
        return (
            <div>
                Not Found
            </div>
        )
    }
}
export default Notfound; 