import React from 'react';

class ForgotPassword extends React.Component {
    render() {
        // const param = this.props.match.params;
        return (
            <div>
                Forgot Password
            </div>
        )
    }
}

export default ForgotPassword;