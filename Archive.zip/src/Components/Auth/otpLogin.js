import { Container, Header, Content, Item, Input, Icon, Card, Label } from 'native-base';
import { onSignIn } from "../Auth/AuthLoading";
import React, { Component } from 'react';
import {
    StyleSheet, ImageBackground,
    Text,
    View,
    TextInput,
    TouchableHighlight,
    Image,
    Alert
} from 'react-native';
export default class SignIn extends Component {
    static navigationOptions = {
        headerMode: 'none'
    }
    constructor(props) {
        super(props);
        state = {
            email: '',
            password: '',
        }
    }

    onClickListener = (viewId) => {
        Alert.alert("Alert", "Button pressed " + viewId);
    }

    render() {
        return (
            <Container style={styles.container}>

                <Content>
                    <Card>

                        <Item floatingLabel>
                            <Label>Username</Label>
                            <Icon active name='home' />
                            <Input />
                        </Item>
                        <Item floatingLabel last>
                            <Icon active name='home' />
                            <Label>Password</Label>
                            <Input />
                        </Item>
                    </Card>
                </Content>
            </Container>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row',
        //justifyContent: 'center',
        alignItems: 'center',
        //backgroundColor: '#DCDCDC',
        //padding: 8
    },
    backgroundImage: {
        // flex: 1,
        width: '100%',
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        resizeMode: 'cover', // or 'stretch'
    },
    inputContainer: {
        borderBottomColor: '#F5FCFF',
        backgroundColor: '#FFFFFF',
        // borderRadius: 30,
        borderBottomWidth: 1,
        width: 250,
        height: 45,
        marginBottom: 20,
        flexDirection: 'row',
        alignItems: 'center'
    },
    inputs: {
        height: 45,
        marginLeft: 16,
        borderBottomColor: '#FFFFFF',
        flex: 1,
    },
    inputIcon: {
        width: 30,
        height: 30,
        marginLeft: 15,
        justifyContent: 'center'
    },
    buttonContainer: {
        height: 45,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 20,
        width: 250,
        //borderRadius: 30,
    },
    loginButton: {
        backgroundColor: "#00b5ec",
    },
    loginText: {
        color: 'white',
    }
});
