import { onSignIn } from "../Auth/AuthLoading";
import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import { Root, Container, Header, Content, Button, Item, Toast, Input, Text, Card, CardItem, Thumbnail, Icon, Left, Body, Right, Row } from 'native-base';
export const USER_KEY = "auth-demo-key";

export default class SignIn extends Component {
  static navigationOptions = {
    headerMode: 'none'
  }
  constructor(props) {
    super(props);
    state = {
      userName: '',
      password: '',
    }
  }
  SingIn = () => {
    onSignIn(this.state).then((d) => {
      Toast.show({
        text: 'Login password!',
        buttonText: 'Okay'
      });
      //AsyncStorage.setItem(USER_KEY, "true");
      setTimeout(() => {
        this.props.navigation.navigate("App")
      }, 2000);

    }).catch(() => Toast.show({
      text: 'Wrong password!',
      buttonText: 'Okay'
    }));
  }

  render() {
    return (
      <Root>
        <Container style={{ flex: 1, flexDirection: 'row', alignItems: 'center', padding: 8 }}>

          <Content>
            <Body>
              <Thumbnail style={{ width: 100 }} source={require('../../Images/LOGO.png')} />
            </Body>
            <Card transparent>
              <CardItem>
                <Item >
                  <Icon name='person' />
                  <Input onChangeText={(userName) => this.setState({ userName })} placeholder="User Name" />
                </Item>
              </CardItem>
              <CardItem>
                <Item>
                  <Icon name="compass" />
                  <Input secureTextEntry={true}
                    onChangeText={(password) => this.setState({ password })} placeholder="Password" />
                </Item>
              </CardItem>

              <CardItem>
                <Body>
                  <Button info block onPress={this.SingIn}>
                    <Text>Login</Text>
                  </Button>
                </Body>
              </CardItem>

            </Card>
          </Content>

        </Container>
      </Root>

    );
  }
}