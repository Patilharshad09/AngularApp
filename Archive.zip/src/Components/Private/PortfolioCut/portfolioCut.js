import React from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import { StyleSheet, FlatList, Text, Dimensions } from "react-native";
import { Container, Header, Content, List, ListItem, InputGroup, Input, Icon, View, Segment, Button, Footer, Tabs, Tab, TabHeading } from 'native-base';

import axios from 'axios';
import GroupExposure from '../GroupExposure';

export default class PortfolioCut extends React.Component {
    static navigationOptions = {
        title: 'Porfolio Cut',
    };
    constructor() {
        super();
        this.state = {
            pCut: [],
            rawData: [],
            keyName: '',
            loading: false
        }
    }

    onSearch = (event) => {
        this.setState((state, props) => ({
            groupName: event,
            loading: true
        }));
        if (event.length > 0) {
            var d = this.state.rawData.filter((item) => {
                if (item['Group Name'].toLowerCase().indexOf(event.trim().toLowerCase()) > -1)
                    return item;
            });
            this.setState({
                pCut: d,
                loading: false
            })
        }
        else {
            this.setState((prevState) => ({
                pCut: prevState.rawData,
                loading: false
            }));
        }
    }
    componentDidMount() {
        var props = {
            name: "getPortfolioCuts",
            value: undefined
        }
        var data = { "value": JSON.stringify(props) };
        axios.post('https://125.63.82.87:97/api/post', data).then((result) => {
            this.setState({
                pCut: pCut,
                rawData: pCut,
                groupName: '',
                loading: false
            });
        }).catch((err) => {
            console.log(err);
        });
    }

    renderBlock = ({ item, index }) => {
        if (item.empty === true) {
            return <View style={[styles.item, styles.invisible]}></View>
        }
        return (
            <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />);
    }
    render() {
        return (
            <Container>
                <Header searchBar >
                    <InputGroup style={{ flex: 1, flexDirection: 'row' }}>
                        <Icon name="search" style={{ color: '#384850' }} />
                        <Input style={{ color: '#00c497' }} value={this.state.groupName}
                            onChangeText={this.onSearch} />
                    </InputGroup>
                </Header>
                <Content padder>
                    <FlatList data={this.state.pCut}
                        //style={styles.container}
                        renderItem={this.renderBlock}
                    //numColumns={numOfCols}
                    />

                    {/* {<List dataArray={this.state.pCut} renderRow={(item, i) =>
                        <GroupExposure key={i} exposure={item} clickhandler={() => this._showMoreApp(item)} />
                    } />} */}
                </Content>
                <Footer>
                    <Tabs>
                        <Tab onChangeTab={() => alert('all')} heading={<TabHeading><Text style={styles.itemText}>All</Text></TabHeading>}></Tab>
                        <Tab onChangeTab={() => alert('90')} heading={<TabHeading><Text style={styles.itemText}><Icon name="alert" /></Text></TabHeading>}></Tab>
                        <Tab onChangeTab={() => alert('bookmark')} heading={<TabHeading><Text style={styles.itemText}> <Icon name="bookmark" /></Text></TabHeading>}></Tab>
                        <Tab onChangeTab={() => alert('other')} heading={<TabHeading><Icon name="apps" /></TabHeading>}></Tab>
                    </Tabs>
                </Footer>
            </Container>
        );
    }
    _showMoreApp = (d) => {
        this.props.navigation.navigate('IssuerExposure', {
            group: d
        });
    };
    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    item: {
        backgroundColor: '#005493',
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
        margin: 1,
        //height: Dimensions.get('window').width / numOfCols
    },
    itemText: {
        color: '#fff',
        fontSize: 14,
        fontWeight: 'bold'
    },
    invisible: {
        backgroundColor: "transparent"
    }
})