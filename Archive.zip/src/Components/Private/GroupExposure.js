import React from 'react';
import { ListItem, Text, Left, Body, Right, Button, Icon, Form, Picker } from 'native-base';

export default class GroupExposure extends React.Component {
    constructor() {
        super();
        this.state = {
            selected: "key1"
        }
    }
    componentDidMount() {
    }
    onValueChange(value) {
        this.setState({
            selected: value
        });
    }
    render() {
        return (
            // <List>
            <ListItem Thumbnail >
                <Body >
                    <Text>{this.props.exposure['Group Name']} <Text note>({this.props.exposure['AK Company']})</Text></Text>
                    <Text note numberOfLines={1}>
                        Limit : {this.props.exposure['Group Exposure Limit']}&nbsp;
                            POS : {this.props.exposure['Principal Outstanding']}&nbsp;
                            Avail :{this.props.exposure['Group Limit Available']}
                    </Text>
                </Body>
                <Right>
                    <Button transparent onPress={() => this.props.clickhandler(this.props.exposure)}>
                        <Icon name="arrow-down" />
                    </Button>
                </Right>
            </ListItem>
            //</List>
        );
    }


    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}