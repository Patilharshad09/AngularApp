import React from 'react';
import { SafeAreaView } from 'react-navigation';
import AsyncStorage from '@react-native-community/async-storage';
import { companyExposure } from '../../../src/companyExposure.json';
import groupExposure from '../../../src/groupExposure.json';
// import { Container, Header, Content, Card, CardItem, Text, Body, Button } from "native-base";
import { Container, Header, Content, List, ListItem, Thumbnail, Text, Left, Body, Right, Button, Icon } from 'native-base';
import axios from 'axios';

export default class Exposure extends React.Component {
    static navigationOptions = {
        title: 'DashBaord',
    };
    constructor() {
        super();

    }
    componentDidMount() {
        console.log(groupExposure);
    }
    render() {
        // const components = {
        //     photo: Notifications,
        //     video: CollapsiblePanel
        // };
        // const Component = components['video'];
        // return (<Component />);
        let element = groupExposure.map(function (object, i) {
            return (
                <List key={i}>
                    <ListItem Thumbnail>
                        {/* <Left>
                            <Icon name="alert" style={{ color: 'red' }} />
                        </Left> */}
                        <Body>
                            <Text>{object['Group Name']} <Text note>({object['AK Company']})</Text></Text>

                            <Text note numberOfLines={1}>Limit : {object['Group Exposure Limit']} POS : {object['Principal Outstanding']} Avail :{object['Group Limit Available']}  </Text>
                        </Body>
                        <Right>
                            <Icon name="arrow-down" />
                        </Right>
                    </ListItem>
                </List>
            )
        });
        return (
            <SafeAreaView>
                <Container>
                    <Content>
                        {element}
                    </Content>
                </Container>
            </SafeAreaView>
        );
    }

    _showMoreApp = () => {
        this.props.navigation.navigate('Other');
    };

    _signOutAsync = async () => {
        await AsyncStorage.clear();
        this.props.navigation.navigate('Auth');
    };
}