import { createStackNavigator } from "react-navigation";
import Password from "../Components/Auth/Password";
import User from "../Components/Auth/userName";

export const AuthRoutes = createStackNavigator(
    {
        User: User,
        Password: Password
    },
    {
        initialRouteName: 'User',
        headerMode: 'none'
    }
);