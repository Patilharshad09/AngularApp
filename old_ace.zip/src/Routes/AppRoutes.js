import React, { Component } from 'react';
import { createDrawerNavigator } from "react-navigation";
import ExposureRoutes from "../Components/Private/index";
import SideBar from "../SideBar/SideBar";

export const AppRoutes = createDrawerNavigator(
    {
        Exposure: ExposureRoutes,
    },
    {
        initialRouteName: 'Exposure',
        headerMode: 'none',
        contentComponent: props => <SideBar {...props} />
    }
);