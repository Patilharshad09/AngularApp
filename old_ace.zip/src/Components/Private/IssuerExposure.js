import React, { Component } from "react";
import { Container, Header, Content, List, Title, ListItem, Thumbnail, Text, Left, Body, Right, Button, Icon } from 'native-base';
import { StyleSheet } from 'react-native';


export default class IssuerExposure extends Component {
    constructor() {
        super();
        this.state = {
            companyExposure: [],
            rawData: [],
            filterGroup: {}
        }
    }
    componentDidMount() {
        const navigation = this.props.navigation;
        this.setState({
            companyExposure: navigation.getParam('singleParty'),
            rawData: navigation.getParam('singleParty'),
            filterGroup: navigation.getParam('group', [])
        });
        // this.props.navigation.addListener('willFocus', this.loadIssuerExposure);
    }
    componentWillUnmount() {
        this.setState({
            companyExposure: [],
            rawData: [],
            filterGroup: {}
        });
    }
    loadIssuerExposure = () => {
        var filterGroup = null;
        filterGroup = this.props.navigation.getParam('group', []);
        this.setState({ filterGroup: filterGroup });
        var d = [];
        if (filterGroup) {
            d = this.state.rawData.filter(item => {
                return (filterGroup['Group Name'] === item['Group Name'] && filterGroup['AK Company'] === item['AK Company']);
            });
            this.setState({
                companyExposure: d,
                rawData: companyExposure
            });
        }
        else {
            this.state = {
                companyExposure: rawData,
                rawData: rawData
            }
        }
    }
    _showMoreApp = (d) => {
        this.props.navigation.navigate('IssuerSummary', {
            company: d
        });
    };
    render() {
        return (
            <Container style={{ marginTop: 20 }}>
                <Content>
                    <Header>
                        <Left>
                            <Button transparent onPress={() => this.props.navigation.goBack()}>
                                <Icon name='arrow-back' />
                            </Button>
                        </Left>
                        <Body>
                            <Title>{this.state.filterGroup['Group Name']} <Text note>({this.state.filterGroup['AK Company']})</Text></Title>
                        </Body>
                    </Header>
                    {this.state.companyExposure ? this.state.companyExposure.map((item, i) => {
                        return (
                            <List key={i}>
                                <ListItem Thumbnail onPress={() => this._showMoreApp(item)}>

                                    <Body>
                                        <Text>{item['Company Name']}</Text>
                                        <Text note numberOfLines={1}>
                                            Limit : {item['Single Party Exposure Limit']} &nbsp;
                                            POS : {item['Principal Outstanding']}&nbsp;
                                            Avail :{item['Single Party Limit Available']}
                                        </Text>
                                    </Body>
                                    <Right>
                                        <Button transparent onPress={() => this._showMoreApp(item)}>
                                            <Icon name="arrow-down" />
                                        </Button>
                                    </Right>
                                </ListItem>
                            </List>
                        )
                    }) : <Text>Do Data Found</Text>}
                </Content>
            </Container>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    itemText: {
        color: '#fff',
        fontSize: 20,
        fontWeight: 'bold'
    },
    invisible: {
        backgroundColor: "transparent"
    }
})