import React from 'react';
import Exposure from './Exposure';
import IssuerExposure from './IssuerExposure';
import IssuerSummary from './IssuerSummary';
import { createStackNavigator } from 'react-navigation';

export default createStackNavigator(
    {
        GroupExposure: Exposure,
        IssuerSummary: IssuerSummary,
        IssuerExposure: IssuerExposure
    }, {
        initialRouteName: 'GroupExposure',
        headerMode: 'none'
    }
);